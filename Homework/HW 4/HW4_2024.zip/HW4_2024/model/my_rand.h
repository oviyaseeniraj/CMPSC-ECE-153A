#ifndef my_rand_h
#define my_rand_h

#include <stdint.h>
void my_srand( uint32_t foo);
uint32_t my_rand(void);

#endif                                                         /* my_rand_h */
